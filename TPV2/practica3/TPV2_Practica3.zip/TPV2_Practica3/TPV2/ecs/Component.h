#pragma once

struct Component {
	virtual ~Component() {}
};