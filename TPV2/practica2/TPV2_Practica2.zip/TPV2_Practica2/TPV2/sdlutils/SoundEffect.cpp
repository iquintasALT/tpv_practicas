#include "SoundEffect.h"

int SoundEffect::channels_ = 0;
