Esta carpeta sirve para almacenar la partida guardada.
No eliminarla o generará errores de ejecución.